# DataCleaning
- Data cleaning refers to all kinds of tasks and activities to Detect and repair Errors in the Data. (or)
- It is the identifcation and correction of errors in the dataset that may negatively impact a predictive model.

For removing Null Values, refer the <i>Data_Cleaning_Null.ipynb</i> file.


You can access the Fraud.csv file by clicking the link: https://drive.google.com/file/d/1D6hpncWVwleX7ZZHFlODGXu2yfofOzZl/view?usp=sharing

You can access the titanic.csv file by clicking the link:https://drive.google.com/file/d/1Z2BEydj6-FU_Q0a3j2y4phM1RjCEZmg_/view?usp=sharing
